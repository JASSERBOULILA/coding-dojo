package com.travels.savetravles.controllers;


import com.travels.savetravles.models.Travels;
import com.travels.savetravles.services.TravelServices;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@Controller
public class Controllers {
    @Autowired
    private TravelServices travelServices;

    @GetMapping("/")
    private String show(@Valid @ModelAttribute("travels") Travels travels, Model model){
        List<Travels> allTravels = travelServices.allTravels();
        model.addAttribute("alltravels", allTravels);
        return "index.jsp";
    }

    @PostMapping("/travels/new")
    public String create(@Valid @ModelAttribute("travels") Travels travels, BindingResult result) {
        if (result.hasErrors()) {
            return "index.jsp";
        } else {
            travelServices.createTravel(travels);
            return "redirect:/";
        }
    }

//    @PostMapping("/travels/new")
//    public String createNewTravels(@Valid @ModelAttribute("travels") Travels travels , BindingResult result , Model model){
//        if(result.hasErrors()){
//            List<Travels> allTravels = travelServices.allTravels();
//            model.addAttribute("alltravels" , allTravels);
//            return "index.jsp";
//        }else{
//            Travels newTravels =  travelServices.createTravel(travels);
//            return "redirect:/";
//        }
//    }

    @GetMapping("/travels/edit/{id}")
    public String editTravel(@Valid @ModelAttribute("travels") Travels travels , BindingResult result , Model model){
        if(result.hasErrors()){
            return "editTravels.jsp";
        }else{
            travelServices.updateTravels(travels);
            return "redirect:/";
        }
    }
    @PutMapping("/travels/edit/{id}")
    public String updateOneTravel(@Valid @ModelAttribute("travels") Travels travels  , BindingResult result){
        if(result.hasErrors()){
            return "editTravels.jsp";
        }else{
            travelServices.updateTravels(travels);
            return "redirect:/";
        }
    }


}

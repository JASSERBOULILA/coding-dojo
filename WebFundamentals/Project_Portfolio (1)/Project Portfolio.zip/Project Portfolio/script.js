const body = document.querySelector('body')
const toggle = document.getElementById('toggle');
toggle.onclick = function () {
    toggle.classList.toggle('active');
    body.classList.toggle('active');
}

function removebtn(id) {
    var element = document.querySelector(id);
    element.remove();
}

window.addEventListener("load", () => {
    const loader = document.querySelector(".loader");

    loader.classList.add("loader-hidden");

    loader.addEventListener("transitionend", () => {
        document.body.removeChild("loader");
    })
})

var typed = new Typed('.auto-type', {
    strings: ['Developer','Gamer','Guitar Player'],
    typeSpeed: 150,
    backSpeed: 150,
    loop:true
})


// hamburger event
// var ham=document.querySelector(".bi");
// var nav=document.getElementById("#navbar");
// ham.addEventListener("click",()=>{
//     alert("hemburger clicked");
//     ham.style.display="none";
//     if(ham.style.display=="none"){  
//         nav.style.display="block";
//         nav.classList.toggle("nav-menu");
//     }
// })



//changing cv to other

var h1=document.getElementById("h1").innerText;
var right=document.querySelector("#right");
var left=document.querySelector("#left");
var div=document.querySelector("#profile");
var leftTest=document.querySelector("#left-link");
var rightTest=document.querySelector("#right-link")
var pages1="jasser.html";

// right.remove();
// right.fill=""
// left.remove();

document.getElementById("profile").addEventListener("mouseover",()=>{
    console.log("jasser");
    if(h1=="Anis Rouis"){
        // document.getElementById("profile").innerHTML = "<a href=''><svg id='left' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-left' viewBox='0 0 16 16'><path d='M10 12.796V3.204L4.519 8 10 12.796zm-.659.753-5.48-4.796a1 1 0 0 1 0-1.506l5.48-4.796A1 1 0 0 1 11 3.204v9.592a1 1 0 0 1-1.659.753z'/></svg></a>" +
        // "<img src='./images/ninjalogo.png' alt='' class='img-fluid rounded-circle mt-5'>" +
        // "<a href='souleim.html'><svg id='right' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-right' viewBox='0 0 16 16'><path d='M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z'/></svg></a>";
        leftTest.href="jasser.html"
        rightTest.href="souleim.html";
    }else if(h1=="Jasser Boulila")
    {
        leftTest.href="souleim.html";
        rightTest.href="portfolio.html";
        // div.innerHTML = "<a href='souleim.html'><svg id='left' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-left' viewBox='0 0 16 16'><path d='M10 12.796V3.204L4.519 8 10 12.796zm-.659.753-5.48-4.796a1 1 0 0 1 0-1.506l5.48-4.796A1 1 0 0 1 11 3.204v9.592a1 1 0 0 1-1.659.753z'/></svg></a>" +
        // "<img src='./images/ninjalogo.png' alt='' class='img-fluid rounded-circle mt-5'>" +
        // "<a href='souleim.html'><svg id='right' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-right' viewBox='0 0 16 16'><path d='M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z'/></svg></a>";
    }else if(h1=="Souleim Ben Said"){
        leftTest.href="portfolio.html";
        rightTest.href="jasser.html";
    }
});

// window.onload = function() {
//     document.getElementById("profile").addEventListener("load",()=>{
//         right.style.display = "none";;
//         left.style.display="none";
//     });
// };

// div.addEventListener('mouseover',()=>{

    
//     if(h1=="Anis Rouis"){
//         console.log("jasser");
//         // leftTest.href="jasser.html"
//         div.innerHTML = "<a href='jasser.html'><svg id='left' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-left' viewBox='0 0 16 16'><path d='M10 12.796V3.204L4.519 8 10 12.796zm-.659.753-5.48-4.796a1 1 0 0 1 0-1.506l5.48-4.796A1 1 0 0 1 11 3.204v9.592a1 1 0 0 1-1.659.753z'/></svg></a>" +
//         "<img src='./images/ninjalogo.png' alt='' class='img-fluid rounded-circle mt-5'>" +
//         "<a href='souleim.html'><svg id='right' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-right' viewBox='0 0 16 16'><path d='M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z'/></svg></a>";
    
//     }else if(h1=="Jasser Boulila")
//     {
//         div.innerHTML = "<a href='souleim.html'><svg id='left' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-left' viewBox='0 0 16 16'><path d='M10 12.796V3.204L4.519 8 10 12.796zm-.659.753-5.48-4.796a1 1 0 0 1 0-1.506l5.48-4.796A1 1 0 0 1 11 3.204v9.592a1 1 0 0 1-1.659.753z'/></svg></a>" +
//         "<img src='./images/ninjalogo.png' alt='' class='img-fluid rounded-circle mt-5'>" +
//         "<a href='souleim.html'><svg id='right' xmlns='http://www.w3.org/2000/svg' width='25' height='25' fill='currentColor' class='bi bi-caret-right' viewBox='0 0 16 16'><path d='M6 12.796V3.204L11.481 8 6 12.796zm.659.753 5.48-4.796a1 1 0 0 0 0-1.506L6.66 2.451C6.011 1.885 5 2.345 5 3.204v9.592a1 1 0 0 0 1.659.753z'/></svg></a>";
//     }
// });


// on('click', '.mobile-nav-toggle', function (e) {
//     select('container-main').classList.toggle('mobile-nav-active')
//     this.classList.toggle('bi-list')
//     this.classList.toggle('bi-x')
// })



// on('click', '.scrollto', function (e) {
//     if (select(this.hash)) {
//         e.preventDefault()

//         let body = select('body')
//         if (body.classList.contains('mobile-nav-active')) {
//             body.classList.remove('mobile-nav-active')
//             let navbarToggle = select('.mobile-nav-toggle')
//             navbarToggle.classList.toggle('bi-list')
//             navbarToggle.classList.toggle('bi-x')
//         }
//         scrollto(this.hash)
//     }
// }, true)

// window.addEventListener('load', () => {
//     if (window.location.hash) {
//         if (select(window.location.hash)) {
//             scrollto(window.location.hash)
//         }
//     }
// });


// hamburger button


window.onload=function(){
    const menu_btn=document.querySelector(".humburger");
    menu_btn.addEventListener('click',function(){
        menu_btn.classList.add('is-active');
    });
    menu_btn.classList.remove('is-active');
}



//active-nav{
    //MARGIN:0;
    //ACTIVE6CONT:; 
//       }
// 
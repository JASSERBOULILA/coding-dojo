// document.getElementById("Prev").addEventListener('click',()=>{
//     if(document.getElementById("first-slid").src=="./images/Anis.jpg"){

//     }
// });
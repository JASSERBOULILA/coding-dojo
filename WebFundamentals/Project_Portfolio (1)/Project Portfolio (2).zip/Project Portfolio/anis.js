var typed = new Typed('.auto-type', {
    strings: ['Developer','Gamer','Guitar Player'],
    typeSpeed: 150,
    backSpeed: 150,
    loop:true
})
const carousel = new bootstrap.Carousel('#myCarousel')
var typed = new Typed('.auto-type', {
    strings: ['Developer','Actor','Peinter'],
    typeSpeed: 150,
    backSpeed: 150,
    loop:true
})